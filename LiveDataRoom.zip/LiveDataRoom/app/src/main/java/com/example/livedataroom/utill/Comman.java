package com.example.livedataroom.utill;

public class Comman {
    public static final String USER_TABLE="user_table";
    public static final String USER_NUMBER="user_number";
    public static final String USER_DATABASE="user_database";
    public static final String USER_NAME="user_name";
    public static final String USER_LASTNAME="user_last_name";


}
